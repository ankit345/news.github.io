export class BuyParams {
  total_cost: number;
  total_items: number;
  items_ref: Array<number>;
}
