export class VoucherCodeResponse {
  success: boolean;
  description: string;
}
