import { Component } from '@angular/core';

@Component({
  selector: 'app-network-error-component',
  templateUrl: './network-error.component.html',
  styleUrls: ['./network-error.component.scss']
})
export class NetworkErrorComponent {

  constructor() { }

}
