export interface IEnvironment {
  production: boolean;
  storeApiPath: string;
}
