import { IEnvironment } from './environment.interface';

export const environment: IEnvironment = {
  production: true,
  storeApiPath: 'https://swapi.co/api'
};
